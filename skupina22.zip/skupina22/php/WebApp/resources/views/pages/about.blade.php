@extends('layouts.app')

@section('content')
    <h1>Welcome To About Page!</h1>
@endsection
