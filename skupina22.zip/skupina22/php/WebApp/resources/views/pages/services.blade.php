@extends('layouts.app')

@section('content')
    <h1>Welcome To Services Page!</h1>
@endsection
