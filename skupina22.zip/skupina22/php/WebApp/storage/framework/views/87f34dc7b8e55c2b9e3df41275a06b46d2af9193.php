<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($item->name); ?>

                        <a style='float: right;' href='/' class="btn btn-primary">
                            <?php echo e(__('Back')); ?>

                        </a>
                    </div>

                    <div class="card-body">
                        <div>Name of item:  <strong><?php echo e($item->name); ?></strong></div>
                        <div>Price:  <strong><?php echo e($item->price); ?></strong></div>
                        <div>Description:  <strong><?php echo e($item->description); ?></strong></div>
                        <div>Date of last update:  <strong><?php echo e($item->updated_at); ?></strong></div>
                        <div><strong><h3>Price: <?php echo e($item->price); ?> €</h3></strong></div>
                        <?php if(Auth::guest() || Auth::user()->role == 'customer'): ?>
                        <a href="/shop/add/<?php echo e($item->id); ?>" class="btn btn-dark" style="float: right">Add to basket</a>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jakob/Documents/EP-projekt/WebApp/resources/views/items/item-show.blade.php ENDPATH**/ ?>