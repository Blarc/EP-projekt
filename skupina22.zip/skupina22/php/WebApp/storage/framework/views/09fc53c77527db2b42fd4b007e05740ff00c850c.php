<?php $__env->startSection('content'); ?>
    <?php if(Auth::guest()): ?>
        <div class="jumbotron text-center">
            <h1>Welcome To E-Shopping!</h1>
            <p>
                <a class="btn btn-primary btn-lg" href="/login" role="button">Login</a>
                <a class="btn btn-success btn-lg" href="/register" role="button">Register</a>
            </p>
        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3>Items</h3>
                        <a style='float: right; margin-left: 1ex' href='/edit-profile' class="btn btn-primary">
                            <?php echo e(__('Edit profile')); ?>

                        </a>
                        <?php if(!Auth::guest() && Auth::user()->role == 'customer'): ?>
                        <a style='float: right; margin-left: 1ex' href='/home' class="btn btn-primary">
                            <?php echo e(__('My Shopping Lists')); ?>

                        </a>
                        <?php endif; ?>
                    </div>


                    <div class="card-body">
                        <?php if(count($items) > 0): ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="well">
                                    <span style='display: inline;'>
                                        <h3><a href="/shop/item-show/<?php echo e($item->id); ?>"><?php echo e($item->name); ?> <?php echo e($item->id); ?> </a> <div style='float: right;'><?php echo e($item->price); ?> €</div></h3>
                                        <h4></h4>
                                    </span>
                                    <small>added <?php echo e($item->created_at); ?></small><br>
                                    <small>updated <?php echo e($item->updated_at); ?></small>
                                    <?php if(Auth::guest() || Auth::user()->role == 'customer'): ?>
                                        <a href="/shop/add/<?php echo e($item->id); ?>" class="btn btn-dark" style="float: right">Add to basket</a>
                                    <?php endif; ?>
                                    <hr>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($items->links()); ?>

                        <?php else: ?>
                            <p>No items found</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jakob/Documents/EP-projekt/WebApp/resources/views/items/index.blade.php ENDPATH**/ ?>