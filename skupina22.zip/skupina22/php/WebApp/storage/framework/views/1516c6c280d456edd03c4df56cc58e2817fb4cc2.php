<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e($sl->name); ?>

                        <a style='float: right;' href='/home' class="btn btn-primary">
                            <?php echo e(__('My shopping lists')); ?>

                        </a>
                        <a style='float: right; margin-right: 20px;' href='/' class="btn btn-primary">
                            <?php echo e(__('Back to shopping')); ?>

                        </a>
                    </div>

                    <div class="card-body">
                        <div>Name of user:  <strong><?php echo e($sl->user->firstName); ?> <?php echo e($sl->user->lastName); ?></strong></div>
                        <div>Name of shopping list:  <strong><?php echo e($sl->name); ?></strong></div>
                        <div>Date of creation:  <strong><?php echo e($sl->created_at); ?></strong></div>
                        <div>Date of last update:  <strong><?php echo e($sl->updated_at); ?></strong></div>
                        <div>Id:  <strong><?php echo e($sl->id); ?></strong></div>
                        <div>Status:  <strong><?php echo e($sl->status); ?></strong></div>

                        <div class="card-header">Items</div>
                        <div class="card-body">
                            <?php if(count($sl -> items) > 0): ?>
                                <?php $__currentLoopData = $sl -> items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="column well" style="float: left; width: 20%"><?php echo e($item->name); ?></div>
                                        <div class="column well" style="float: left; width: 20%"><?php echo e($item->price); ?>€</div>
                                        <div class="column well" style="float: left; width: 20%"><?php echo e($item->pivot->items_amount); ?>x</div>
                                        <div class="column well" style="float: left; width: 40%">
                                            <?php if($sl->status == 3): ?>
                                                <form method="POST" action="/shoppingList/amount/<?php echo e($sl->id); ?>/<?php echo e($item->id); ?>">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="form-group">
                                                        <label for="items_amount">amount</label>

                                                        <input id="items_amount" type="number" step="1" min="1" class="form-control <?php $__errorArgs = ['items_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="items_amount" value="<?php echo e($item->pivot->items_amount); ?>" required autocomplete="items_amount" autofocus>

                                                        <?php $__errorArgs = ['items_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <a href="/shop/delete/<?php echo e($sl->id); ?>/<?php echo e($item->id); ?>" class="btn btn-danger" style="float: right; margin-left: 0.5ex; margin-top: 0.5ex">Delete item</a>
                                                        <button type="submit" style="float: right; margin-top: 0.5ex" class="btn btn-primary">Calculate</button>
                                                    </div>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No items in shopping list</p>
                            <?php endif; ?>
                        </div>
                        <div style="float: right"><h4>Total amount: <?php echo e($sl->totalAmount()); ?>€</h4></div><br><br>
                        <?php if(count($sl -> items) > 0): ?>
                            <?php if($sl->status == 3): ?>
                                <a href="/shop/sl/<?php echo e($sl->id); ?>/checkout" class="btn btn-dark" style="float: right">Checkout</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jakob/Documents/EP-projekt/WebApp/resources/views/customer/slshow.blade.php ENDPATH**/ ?>