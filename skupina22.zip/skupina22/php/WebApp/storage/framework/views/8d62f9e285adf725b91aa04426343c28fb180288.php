<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(__('Active shopping lists')); ?>

                        <a style='float: right; margin-left: 1ex' href='/edit-profile' class="btn btn-primary">
                            <?php echo e(__('Edit profile')); ?>

                        </a>
                    </div>
                    <div class="card-body">
                        <?php if(count($shoppingLists) > 0): ?>
                            <?php $__currentLoopData = $shoppingLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="well">
                                    <?php if($sl->status == 3): ?>
                                        <h3><a href="/shop/shoppingLists/<?php echo e($sl->id); ?>"><?php echo e($sl->name); ?></a></h3>
                                        <small>added <?php echo e($sl->created_at); ?></small><br>
                                        <small>updated <?php echo e($sl->updated_at); ?></small>
                                        
                                        <a href="/shop/sl/<?php echo e($sl->id); ?>/checkout" class="btn btn-dark" style="float: right">Checkout</a>
                                        <hr>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No shopping lists found</p>
                        <?php endif; ?>
                    </div>

                    <div class="card-header"><?php echo e(__('Pending shopping lists')); ?></div>

                    <div class="card-body">
                        <?php if(count($shoppingLists) > 0): ?>
                            <?php $__currentLoopData = $shoppingLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="well">
                                    <?php if($sl->status == 0): ?>
                                        <h3><a href="/shop/shoppingLists/<?php echo e($sl->id); ?>"><?php echo e($sl->name); ?></a></h3>
                                        <small>added <?php echo e($sl->created_at); ?></small><br>
                                        <small>updated <?php echo e($sl->updated_at); ?></small>

                                        <hr>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No shopping lists found</p>
                        <?php endif; ?>
                    </div>

                    <div class="card-header"><?php echo e(__('Processed shopping lists')); ?></div>

                    <div class="card-body">
                        <?php if(count($shoppingLists) > 0): ?>
                            <?php $__currentLoopData = $shoppingLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="well">
                                    <?php if($sl->status == 1): ?>
                                        <h3><a href="/shop/shoppingLists/<?php echo e($sl->id); ?>"><?php echo e($sl->name); ?></a></h3>
                                        <small>added <?php echo e($sl->created_at); ?></small><br>
                                        <small>updated <?php echo e($sl->updated_at); ?></small>

                                        <hr>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No shopping lists found</p>
                        <?php endif; ?>
                    </div>

                    <div class="card-header"><?php echo e(__('Stornated shopping lists')); ?></div>

                    <div class="card-body">
                        <?php if(count($shoppingLists) > 0): ?>
                            <?php $__currentLoopData = $shoppingLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="well">
                                    <?php if($sl->status == 2): ?>
                                        <h3><a href="/shop/shoppingLists/<?php echo e($sl->id); ?>"><?php echo e($sl->name); ?></a></h3>
                                        <small>added <?php echo e($sl->created_at); ?></small><br>
                                        <small>updated <?php echo e($sl->updated_at); ?></small>

                                        <hr>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No shopping lists found</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jakob/Documents/EP-projekt/WebApp/resources/views/customer/home.blade.php ENDPATH**/ ?>