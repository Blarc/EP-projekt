<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    ADMIN Dashboard
                    <a style='float: right;' href='/edit-profile' class="btn btn-primary">
                        <?php echo e(__('Edit profile')); ?>

                    </a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <ul class="list-group">
                        <?php $__currentLoopData = Auth::user()->sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($seller->firstName); ?>

                                <?php echo e($seller->lastName); ?>

                                <a style='float: right;' href='<?php echo e(route('manageSeller.submit', $seller->id)); ?>' type="button" class="btn btn-primary btn-sm">Edit seller profile</a>
                                <?php if($seller->active): ?>
                                    <a style='float: right;' href='<?php echo e(route('changeProfileStatus', $seller->id)); ?>' type="button" class="btn btn-danger btn-sm">Deactivate seller</a>
                                <?php else: ?>
                                <a style='float: right;' href='<?php echo e(route('changeProfileStatus', $seller->id)); ?>' type="button" class="btn btn-success btn-sm">Activate seller</a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </ul>
                    <a type="button" href='<?php echo e(route('createSeller')); ?>' class="btn btn-secondary">Create new seller</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jakob/Documents/EP-projekt/WebApp/resources/views/admin/home.blade.php ENDPATH**/ ?>