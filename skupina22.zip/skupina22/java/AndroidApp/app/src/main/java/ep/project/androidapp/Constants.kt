package ep.project.androidapp


object Constants {
    //    const val URL = "http://192.168.1.176:8082/api/"
    const val URL = "http://192.168.12.108:8082/api/"
}
